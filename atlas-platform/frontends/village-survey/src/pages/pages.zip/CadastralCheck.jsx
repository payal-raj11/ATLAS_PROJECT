function CadastralCheck({ isDarkMode }) {
  const card = `rounded-xl border p-5 ${
    isDarkMode
      ? "bg-slate-800 border-slate-700"
      : "bg-white border-slate-200 shadow-sm"
  }`;

  return (
    <div className="space-y-5">

      {/* PAGE HEADER */}
      <div>
        <h1
          className={`text-2xl font-bold ${
            isDarkMode ? "text-white" : "text-slate-900"
          }`}
        >
          Cadastral Boundary Check
        </h1>

        <p className="text-sm text-slate-500 mt-1">
          Verify village parcels with cadastral maps and detect boundary conflicts
        </p>
      </div>

      {/* TOP SECTION */}
      <div className="grid grid-cols-5 gap-5">

        {/* PARCEL INFORMATION */}
        <div className={`col-span-2 ${card}`}>

          <h2 className="text-lg font-bold mb-5">
            📋 Parcel Information
          </h2>

          <div className="space-y-4 text-sm">

            <div className="flex justify-between">
              <span className="text-slate-500">Survey No.</span>
              <strong>115</strong>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Landowner Name</span>
              <strong>Ramesh Yadav</strong>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Official Area</span>
              <strong>0.900 Ha</strong>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Land Classification</span>
              <strong>Agricultural</strong>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-500">Record Status</span>

              <span className="px-3 py-1 rounded bg-emerald-500/20 text-emerald-500 text-xs font-bold">
                Verified
              </span>
            </div>

          </div>
        </div>

        {/* CADASTRAL MAP */}
        <div className={`col-span-3 ${card}`}>

          <div className="flex justify-between items-center mb-4">

            <h2 className="text-lg font-bold">
              🗺️ Cadastral Map — Malhaur
            </h2>

            <button className="text-blue-500 text-xs font-bold">
              ⛶ Full Map
            </button>

          </div>

          {/* MAP PLACEHOLDER */}
          <div
            className={`h-72 rounded-xl border flex items-center justify-center relative overflow-hidden ${
              isDarkMode
                ? "bg-slate-900 border-slate-700"
                : "bg-slate-100 border-slate-300"
            }`}
          >

            {/* FAKE PARCEL MAP */}
            <div className="absolute inset-5 grid grid-cols-4 grid-rows-3 gap-1 opacity-80">

              <div className="bg-emerald-600/60 border border-white flex items-center justify-center font-bold text-xs">
                113
              </div>

              <div className="bg-emerald-600/60 border border-white flex items-center justify-center font-bold text-xs">
                114
              </div>

              <div className="bg-red-600/70 border-2 border-white flex items-center justify-center font-bold text-white">
                115
              </div>

              <div className="bg-amber-500/60 border border-white flex items-center justify-center font-bold text-xs">
                116
              </div>

              <div className="bg-emerald-600/60 border border-white flex items-center justify-center font-bold text-xs">
                107
              </div>

              <div className="bg-amber-500/60 border border-white flex items-center justify-center font-bold text-xs">
                117
              </div>

              <div className="bg-emerald-600/60 border border-white flex items-center justify-center font-bold text-xs">
                118
              </div>

              <div className="bg-emerald-600/60 border border-white flex items-center justify-center font-bold text-xs">
                119
              </div>

              <div className="bg-slate-700 border border-white flex items-center justify-center font-bold text-xs">
                110
              </div>

              <div className="bg-emerald-600/60 border border-white flex items-center justify-center font-bold text-xs">
                112
              </div>

              <div className="bg-amber-500/60 border border-white flex items-center justify-center font-bold text-xs">
                120
              </div>

              <div className="bg-slate-700 border border-white flex items-center justify-center font-bold text-xs">
                121
              </div>

            </div>

            <div className="z-10 text-xs font-bold bg-slate-900/80 px-3 py-2 rounded-lg">
              GIS / Mapbox / Leaflet Integration
            </div>

          </div>

          {/* LEGEND */}
          <div className="flex gap-6 mt-4 text-xs">

            <span className="text-emerald-500">
              🟢 Verified
            </span>

            <span className="text-amber-500">
              🟡 Pending
            </span>

            <span className="text-red-500">
              🔴 Boundary Clash
            </span>

            <span className="text-slate-500">
              ⬜ Other Parcels
            </span>

          </div>

        </div>

      </div>

      {/* BOTTOM SECTION */}
      <div className="grid grid-cols-5 gap-5">

        {/* BOUNDARY CHECK */}
        <div className={`col-span-2 ${card}`}>

          <h2 className="text-lg font-bold mb-5">
            Boundary Check
          </h2>

          <div className="space-y-4">

            <div className="flex items-center gap-3">
              <span className="w-7 h-7 rounded bg-emerald-500 text-white flex items-center justify-center">
                ✓
              </span>

              <span className="text-sm">
                Matched with cadastral map
              </span>
            </div>

            <div className="flex items-center gap-3">
              <span className="w-7 h-7 rounded bg-amber-500 text-white flex items-center justify-center">
                !
              </span>

              <span className="text-sm">
                Adjacent plot mismatch
              </span>
            </div>

            <div className="flex items-center gap-3">
              <span className="w-7 h-7 rounded bg-red-500 text-white flex items-center justify-center">
                !
              </span>

              <span className="text-sm">
                Boundary clash detected
              </span>
            </div>

          </div>

          <div className="mt-6">

            <label className="text-sm font-bold">
              Remarks
            </label>

            <textarea
              rows="4"
              placeholder="Add boundary verification notes..."
              className={`w-full mt-2 p-3 rounded-lg border text-sm outline-none ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700"
                  : "bg-slate-50 border-slate-300"
              }`}
            />

          </div>

        </div>

        {/* NEARBY PARCELS */}
        <div className={`col-span-3 ${card}`}>

          <h2 className="text-lg font-bold mb-4">
            Nearby Parcels
          </h2>

          <table className="w-full text-sm">

            <thead className="text-xs text-slate-500 border-b border-slate-700">

              <tr>
                <th className="text-left py-3">Survey No.</th>
                <th className="text-left py-3">Landowner</th>
                <th className="text-left py-3">Relation</th>
                <th className="text-left py-3">Status</th>
                <th className="text-left py-3">Remarks</th>
              </tr>

            </thead>

            <tbody>

              <tr className="border-b border-slate-700/50">
                <td className="py-3">114</td>
                <td>Abdul Rahman</td>
                <td>Adjacent (North)</td>
                <td className="text-emerald-500">Verified</td>
                <td>-</td>
              </tr>

              <tr className="border-b border-slate-700/50">
                <td className="py-3">116</td>
                <td>Sushila Devi</td>
                <td>Adjacent (East)</td>
                <td className="text-amber-500">Pending</td>
                <td>Area mismatch</td>
              </tr>

              <tr>
                <td className="py-3">117</td>
                <td>Geeta Singh</td>
                <td>Adjacent (South)</td>
                <td className="text-red-500">Boundary Clash</td>
                <td>Overlapping boundary</td>
              </tr>

            </tbody>

          </table>

          {/* ALERT */}
          <div className="mt-5 p-4 rounded-lg border border-red-500/40 bg-red-500/10">

            <p className="font-bold text-red-500">
              ⚠ Boundary Discrepancy Detected
            </p>

            <p className="text-xs text-slate-500 mt-1">
              Survey No. 115 has a boundary conflict with adjacent
              Survey No. 117. Please verify on ground and escalate if required.
            </p>

          </div>

          {/* ACTIONS */}
          <div className="flex justify-end gap-3 mt-5">

            <button className="px-5 py-2 rounded-lg border border-blue-500 text-blue-500 text-sm font-bold">
              Export Map
            </button>

            <button className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold">
              ✓ Mark as Verified
            </button>

          </div>

        </div>

      </div>

    </div>
  );
}

export default CadastralCheck;