function SurveyOfficers({ isDarkMode }) {
  const officers = [
    {
      name: "Ramesh Kumar",
      id: "SO-014",
      area: "Malhaur North",
      assigned: 42,
      completed: 34,
      progress: 80,
      status: "Active",
    },
    {
      name: "Savitri Devi",
      id: "SO-021",
      area: "Malhaur Central",
      assigned: 35,
      completed: 21,
      progress: 60,
      status: "Active",
    },
    {
      name: "Iqbal Khan",
      id: "SO-018",
      area: "Malhaur South",
      assigned: 30,
      completed: 15,
      progress: 50,
      status: "Active",
    },
    {
      name: "Anil Verma",
      id: "SO-025",
      area: "Malhaur East",
      assigned: 28,
      completed: 25,
      progress: 89,
      status: "On Field",
    },
  ];

  return (
    <div className="space-y-6">

      {/* PAGE HEADER */}
      <div>
        <h1
          className={`text-3xl font-bold ${
            isDarkMode ? "text-white" : "text-slate-900"
          }`}
        >
          Survey Officers
        </h1>

        <p className="text-slate-500 mt-1">
          Monitor field officers, assignments and survey completion
        </p>
      </div>

      {/* KPI CARDS */}
      <div className="grid grid-cols-4 gap-4">

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-400 uppercase">
            Total Officers
          </p>
          <p className="text-3xl font-bold text-sky-400 mt-2">4</p>
          <p className="text-xs text-slate-500 mt-1">
            Assigned to village
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-400 uppercase">
            Active
          </p>
          <p className="text-3xl font-bold text-emerald-500 mt-2">4</p>
          <p className="text-xs text-slate-500 mt-1">
            Currently available
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-400 uppercase">
            Surveys Assigned
          </p>
          <p className="text-3xl font-bold text-blue-500 mt-2">135</p>
          <p className="text-xs text-slate-500 mt-1">
            Across all officers
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-400 uppercase">
            Completed
          </p>
          <p className="text-3xl font-bold text-cyan-400 mt-2">95</p>
          <p className="text-xs text-slate-500 mt-1">
            70% completion rate
          </p>
        </div>

      </div>

      {/* MAIN CONTENT */}
      <div className="grid grid-cols-3 gap-6">

        {/* OFFICER REGISTER */}
        <div
          className={`col-span-2 border rounded-xl p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >

          <div className="flex items-center justify-between mb-5">
            <div>
              <h2
                className={`text-xl font-bold ${
                  isDarkMode ? "text-white" : "text-slate-900"
                }`}
              >
                👥 Survey Officer Register
              </h2>

              <p className="text-sm text-slate-500 mt-1">
                Field activity and assignment progress
              </p>
            </div>

            <button className="text-blue-400 text-sm font-bold hover:text-blue-300">
              View All →
            </button>
          </div>

          {/* SEARCH */}
          <div className="flex gap-3 mb-5">
            <input
              type="text"
              placeholder="Search officer or area..."
              className={`flex-1 px-4 py-3 rounded-lg border outline-none text-sm ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700 text-white placeholder-slate-500"
                  : "bg-slate-50 border-slate-300 text-slate-900"
              }`}
            />

            <button className="px-6 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold text-sm">
              Filter
            </button>
          </div>

          {/* TABLE */}
          <div className="overflow-hidden rounded-lg">
            <table className="w-full text-left text-sm">

              <thead>
                <tr
                  className={`border-b ${
                    isDarkMode
                      ? "border-slate-700 text-slate-400"
                      : "border-slate-200 text-slate-500"
                  }`}
                >
                  <th className="py-3">Officer</th>
                  <th className="py-3">Area</th>
                  <th className="py-3">Assigned</th>
                  <th className="py-3">Completed</th>
                  <th className="py-3">Status</th>
                </tr>
              </thead>

              <tbody>
                {officers.map((officer) => (
                  <tr
                    key={officer.id}
                    className={`border-b ${
                      isDarkMode
                        ? "border-slate-700/60"
                        : "border-slate-200"
                    }`}
                  >
                    <td className="py-4">
                      <div className="flex items-center gap-3">

                        <div className="w-9 h-9 rounded-full bg-sky-500 flex items-center justify-center text-white font-bold">
                          {officer.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </div>

                        <div>
                          <p
                            className={`font-bold ${
                              isDarkMode
                                ? "text-white"
                                : "text-slate-900"
                            }`}
                          >
                            {officer.name}
                          </p>

                          <p className="text-xs text-slate-500">
                            {officer.id}
                          </p>
                        </div>

                      </div>
                    </td>

                    <td className="py-4">
                      {officer.area}
                    </td>

                    <td className="py-4">
                      {officer.assigned}
                    </td>

                    <td className="py-4">
                      {officer.completed}
                    </td>

                    <td className="py-4">
                      <span
                        className={`px-2 py-1 rounded text-xs font-bold ${
                          officer.status === "On Field"
                            ? "bg-blue-500/20 text-blue-400"
                            : "bg-emerald-500/20 text-emerald-400"
                        }`}
                      >
                        {officer.status}
                      </span>
                    </td>

                  </tr>
                ))}
              </tbody>

            </table>
          </div>

        </div>

        {/* SELECTED OFFICER */}
        <div
          className={`border rounded-xl p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >

          <div className="flex items-center justify-between mb-5">
            <div>
              <h2
                className={`text-xl font-bold ${
                  isDarkMode ? "text-white" : "text-slate-900"
                }`}
              >
                📋 Officer Details
              </h2>

              <p className="text-sm text-slate-500 mt-1">
                Selected field officer
              </p>
            </div>

            <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400">
              Active
            </span>
          </div>

          {/* PROFILE */}
          <div className="flex items-center gap-4 pb-5 border-b border-slate-700">
            <div className="w-14 h-14 rounded-full bg-sky-500 flex items-center justify-center text-white text-lg font-bold">
              RK
            </div>

            <div>
              <h3 className="text-lg font-bold text-white">
                Ramesh Kumar
              </h3>
              <p className="text-sm text-slate-500">
                Survey Officer · SO-014
              </p>
            </div>
          </div>

          {/* DETAILS */}
          <div className="space-y-4 mt-5">

            <div className="flex justify-between">
              <span className="text-slate-500">Assigned Area</span>
              <span className="font-bold text-white">
                Malhaur North
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Assigned Surveys</span>
              <span className="font-bold text-white">42</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Completed</span>
              <span className="font-bold text-emerald-400">34</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Pending</span>
              <span className="font-bold text-amber-400">8</span>
            </div>

          </div>

          {/* PROGRESS */}
          <div className="mt-6">

            <div className="flex justify-between mb-2">
              <span className="text-sm text-slate-400">
                Completion Progress
              </span>

              <span className="text-sm font-bold text-emerald-400">
                80%
              </span>
            </div>

            <div className="w-full h-3 rounded-full bg-slate-700 overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full"
                style={{ width: "80%" }}
              ></div>
            </div>

          </div>

          {/* BUTTONS */}
          <div className="mt-6 space-y-2">

            <button className="w-full py-3 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm">
              View Assigned Surveys
            </button>

            <button className="w-full py-3 rounded-lg border border-blue-500 text-blue-400 hover:bg-blue-500/10 font-bold text-sm">
              View Field Activity
            </button>

          </div>

        </div>

      </div>

      {/* FIELD ACTIVITY */}
      <div
        className={`border rounded-xl p-5 ${
          isDarkMode
            ? "bg-slate-800 border-slate-700"
            : "bg-white border-slate-200 shadow-sm"
        }`}
      >

        <div className="flex items-center justify-between mb-5">
          <div>
            <h2
              className={`text-xl font-bold ${
                isDarkMode ? "text-white" : "text-slate-900"
              }`}
            >
              📍 Field Activity Progress
            </h2>

            <p className="text-sm text-slate-500 mt-1">
              Current survey completion across officers
            </p>
          </div>

          <button className="text-blue-400 text-sm font-bold">
            View Field Log →
          </button>
        </div>

        <div className="grid grid-cols-4 gap-6">

          {officers.map((officer) => (
            <div key={officer.id}>

              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">
                  {officer.name}
                </span>

                <span className="text-sm text-slate-400">
                  {officer.progress}%
                </span>
              </div>

              <div className="w-full h-2.5 rounded-full bg-slate-700 overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    officer.progress >= 80
                      ? "bg-emerald-500"
                      : officer.progress >= 60
                      ? "bg-blue-500"
                      : "bg-amber-500"
                  }`}
                  style={{ width: `${officer.progress}%` }}
                ></div>
              </div>

            </div>
          ))}

        </div>

      </div>

      {/* STATUTORY NOTICE */}
      <div className="border-l-4 border-amber-500 bg-slate-800 rounded-r-xl p-4">
        <h3 className="text-amber-400 font-bold text-sm mb-1">
          ⚠️ Field Assignment Notice
        </h3>

        <p className="text-xs text-slate-400">
          8 surveys remain pending for field verification. Officers should
          complete assigned inspections before the statutory review deadline.
        </p>
      </div>

    </div>
  );
}

export default SurveyOfficers;