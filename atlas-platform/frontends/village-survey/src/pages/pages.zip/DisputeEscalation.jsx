import { useState } from "react";

function DisputeEscalation({ isDarkMode }) {
  const [selectedDispute, setSelectedDispute] = useState(0);

  const disputes = [
    {
      survey: "117",
      landowner: "Geeta Singh",
      area: "0.750 Ha",
      type: "Boundary Clash",
      date: "10-09-2025",
      status: "Active",
      authority: "Tehsil Revenue Officer",
      description:
        "Overlapping boundary reported with adjacent Survey No. 115. Field verification required.",
    },
    {
      survey: "121",
      landowner: "Vijay Pal",
      area: "0.920 Ha",
      type: "Ownership Dispute",
      date: "09-09-2025",
      status: "Under Review",
      authority: "SDM Office",
      description:
        "Conflicting ownership claims identified during land record verification.",
    },
    {
      survey: "115",
      landowner: "Ramesh Yadav",
      area: "0.900 Ha",
      type: "Record Dispute",
      date: "08-09-2025",
      status: "Escalated",
      authority: "District Revenue Office",
      description:
        "Discrepancy found between submitted records and existing revenue records.",
    },
  ];

  const active = disputes[selectedDispute];

  return (
    <div className="space-y-6">

      {/* PAGE HEADER */}
      <div>
        <h1
          className={`text-3xl font-bold ${
            isDarkMode ? "text-white" : "text-slate-900"
          }`}
        >
          Dispute Escalation
        </h1>

        <p className="text-slate-500 mt-1">
          Review land disputes, track escalation and record resolution actions
        </p>
      </div>

      {/* KPI CARDS */}
      <div className="grid grid-cols-4 gap-4">

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500 uppercase">
            Active Disputes
          </p>
          <p className="text-3xl font-bold text-red-500 mt-2">3</p>
          <p className="text-xs text-slate-500 mt-1">
            Requiring immediate attention
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500 uppercase">
            Under Review
          </p>
          <p className="text-3xl font-bold text-amber-500 mt-2">2</p>
          <p className="text-xs text-slate-500 mt-1">
            Awaiting verification
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500 uppercase">
            Escalated
          </p>
          <p className="text-3xl font-bold text-blue-500 mt-2">1</p>
          <p className="text-xs text-slate-500 mt-1">
            Sent to higher authority
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500 uppercase">
            Dispute Holds
          </p>
          <p className="text-3xl font-bold text-orange-500 mt-2">3</p>
          <p className="text-xs text-slate-500 mt-1">
            Acquisition activity affected
          </p>
        </div>

      </div>

      {/* MAIN CONTENT */}
      <div className="grid grid-cols-5 gap-6">

        {/* DISPUTE LIST */}
        <div
          className={`col-span-3 rounded-xl border p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2
                className={`text-xl font-bold ${
                  isDarkMode ? "text-white" : "text-slate-900"
                }`}
              >
                ⚖️ Active Land Disputes
              </h2>

              <p className="text-xs text-slate-500 mt-1">
                Disputes requiring verification or escalation
              </p>
            </div>

            <button className="text-blue-500 text-sm font-bold hover:text-blue-400">
              View All →
            </button>
          </div>

          {/* SEARCH */}
          <div className="flex gap-3 mb-5">
            <input
              type="text"
              placeholder="Search survey no. or landowner..."
              className={`flex-1 rounded-lg border px-4 py-2 text-sm outline-none ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700 text-white placeholder:text-slate-500"
                  : "bg-slate-50 border-slate-300 text-slate-900"
              }`}
            />

            <button className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold">
              Filter
            </button>
          </div>

          {/* TABLE */}
          <div className="overflow-hidden">
            <table className="w-full text-left text-sm">
              <thead className="text-xs text-slate-500 uppercase">
                <tr className="border-b border-slate-700/50">
                  <th className="pb-3">Survey No.</th>
                  <th className="pb-3">Landowner</th>
                  <th className="pb-3">Dispute Type</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3">Action</th>
                </tr>
              </thead>

              <tbody>
                {disputes.map((dispute, index) => (
                  <tr
                    key={dispute.survey}
                    className={`border-b border-slate-700/40 cursor-pointer transition ${
                      selectedDispute === index
                        ? "bg-blue-500/10"
                        : "hover:bg-slate-700/20"
                    }`}
                    onClick={() => setSelectedDispute(index)}
                  >
                    <td className="py-4 font-bold text-blue-400">
                      {dispute.survey}
                    </td>

                    <td className="py-4">
                      {dispute.landowner}
                    </td>

                    <td className="py-4">
                      {dispute.type}
                    </td>

                    <td className="py-4">
                      <span
                        className={`px-2 py-1 rounded text-xs font-bold ${
                          dispute.status === "Active"
                            ? "bg-red-500/20 text-red-500"
                            : dispute.status === "Escalated"
                            ? "bg-blue-500/20 text-blue-400"
                            : "bg-amber-500/20 text-amber-500"
                        }`}
                      >
                        {dispute.status}
                      </span>
                    </td>

                    <td className="py-4">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedDispute(index);
                        }}
                        className="text-blue-500 font-bold hover:text-blue-400"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* WARNING */}
          <div className="mt-5 border border-red-500/40 bg-red-500/10 rounded-lg p-4">
            <p className="text-red-500 font-bold text-sm">
              ⚠ Dispute Hold Active
            </p>

            <p className="text-xs text-slate-500 mt-1">
              Land acquisition activity should remain paused for disputed
              parcels until the competent authority records a resolution.
            </p>
          </div>
        </div>

        {/* DETAILS PANEL */}
        <div
          className={`col-span-2 rounded-xl border p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2
                className={`text-xl font-bold ${
                  isDarkMode ? "text-white" : "text-slate-900"
                }`}
              >
                📄 Dispute Details
              </h2>

              <p className="text-xs text-slate-500 mt-1">
                Selected dispute information
              </p>
            </div>

            <span className="px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-500">
              {active.status}
            </span>
          </div>

          {/* DETAILS */}
          <div className="space-y-4">

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Survey No.
              </span>

              <span className="font-bold text-blue-400">
                {active.survey}
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Landowner
              </span>

              <span className="font-bold">
                {active.landowner}
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Area
              </span>

              <span className="font-bold">
                {active.area}
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Dispute Type
              </span>

              <span className="font-bold text-red-400">
                {active.type}
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Reported Date
              </span>

              <span className="font-bold">
                {active.date}
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Authority
              </span>

              <span className="font-bold text-right max-w-[180px]">
                {active.authority}
              </span>
            </div>

          </div>

          {/* DESCRIPTION */}
          <div className="mt-5">
            <h3 className="text-sm font-bold mb-2">
              Dispute Description
            </h3>

            <div
              className={`rounded-lg border p-4 text-sm leading-6 ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700 text-slate-300"
                  : "bg-slate-50 border-slate-200"
              }`}
            >
              {active.description}
            </div>
          </div>

          {/* ACTIONS */}
          <div className="mt-6 space-y-2">

            <button className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 rounded-lg text-sm">
              📤 Escalate to Higher Authority
            </button>

            <button className="w-full bg-amber-500 hover:bg-amber-400 text-white font-bold py-2.5 rounded-lg text-sm">
              📋 Request Field Verification
            </button>

            <button className="w-full border border-emerald-500 text-emerald-500 hover:bg-emerald-500/10 font-bold py-2.5 rounded-lg text-sm">
              ✓ Record Resolution
            </button>

          </div>
        </div>

      </div>

      {/* ESCALATION TIMELINE */}
      <div
        className={`rounded-xl border p-5 ${
          isDarkMode
            ? "bg-slate-800 border-slate-700"
            : "bg-white border-slate-200 shadow-sm"
        }`}
      >
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2
              className={`text-xl font-bold ${
                isDarkMode ? "text-white" : "text-slate-900"
              }`}
            >
              🕒 Escalation Timeline
            </h2>

            <p className="text-xs text-slate-500 mt-1">
              Track actions taken on the selected dispute
            </p>
          </div>

          <button className="text-blue-500 text-sm font-bold">
            View Case History →
          </button>
        </div>

        <div className="grid grid-cols-4 gap-4">

          <div className="border-l-4 border-blue-500 pl-4">
            <p className="text-xs text-slate-500">
              08 Sep 2025
            </p>
            <p className="font-bold mt-1">
              Dispute Reported
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Issue recorded during field verification.
            </p>
          </div>

          <div className="border-l-4 border-amber-500 pl-4">
            <p className="text-xs text-slate-500">
              09 Sep 2025
            </p>
            <p className="font-bold mt-1">
              Field Verification
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Survey records compared with ground evidence.
            </p>
          </div>

          <div className="border-l-4 border-red-500 pl-4">
            <p className="text-xs text-slate-500">
              10 Sep 2025
            </p>
            <p className="font-bold mt-1">
              Dispute Confirmed
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Boundary discrepancy confirmed.
            </p>
          </div>

          <div className="border-l-4 border-slate-600 pl-4">
            <p className="text-xs text-slate-500">
              Next Action
            </p>
            <p className="font-bold mt-1">
              Authority Review
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Awaiting competent authority decision.
            </p>
          </div>

        </div>
      </div>

    </div>
  );
}

export default DisputeEscalation;