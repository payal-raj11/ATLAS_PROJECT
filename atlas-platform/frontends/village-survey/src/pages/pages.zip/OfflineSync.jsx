function OfflineSync({ isDarkMode }) {
  const card = `border rounded-xl ${
    isDarkMode
      ? "bg-slate-800 border-slate-700"
      : "bg-white border-slate-200 shadow-sm"
  }`;

  return (
    <div>
      {/* PAGE HEADER */}
      <div className="mb-8">
        <h1
          className={`text-3xl font-bold ${
            isDarkMode ? "text-white" : "text-slate-900"
          }`}
        >
          Offline / Sync
        </h1>

        <p className="text-slate-500 mt-1">
          Manage offline records, synchronization and field connectivity
        </p>
      </div>

      {/* KPI CARDS */}
      <div className="grid grid-cols-4 gap-5 mb-7">
        <div className={`${card} p-5`}>
          <p className="text-xs font-bold text-slate-400 uppercase">
            Sync Status
          </p>

          <p className="text-3xl font-bold text-emerald-500 mt-2">
            Online
          </p>

          <p className="text-sm text-slate-500 mt-1">
            Connection available
          </p>
        </div>

        <div className={`${card} p-5`}>
          <p className="text-xs font-bold text-slate-400 uppercase">
            Pending Uploads
          </p>

          <p className="text-3xl font-bold text-amber-500 mt-2">
            8
          </p>

          <p className="text-sm text-slate-500 mt-1">
            Records waiting to sync
          </p>
        </div>

        <div className={`${card} p-5`}>
          <p className="text-xs font-bold text-slate-400 uppercase">
            Synced Records
          </p>

          <p className="text-3xl font-bold text-sky-400 mt-2">
            124
          </p>

          <p className="text-sm text-slate-500 mt-1">
            Successfully synchronized
          </p>
        </div>

        <div className={`${card} p-5`}>
          <p className="text-xs font-bold text-slate-400 uppercase">
            Last Sync
          </p>

          <p className="text-3xl font-bold text-emerald-500 mt-2">
            2 min
          </p>

          <p className="text-sm text-slate-500 mt-1">
            Ago
          </p>
        </div>
      </div>

      {/* MAIN AREA */}
      <div className="grid grid-cols-5 gap-6 mb-7">

        {/* SYNC CENTER */}
        <div className={`${card} p-6 col-span-3`}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2
                className={`text-xl font-bold ${
                  isDarkMode ? "text-white" : "text-slate-900"
                }`}
              >
                🔄 Synchronization Center
              </h2>

              <p className="text-sm text-slate-500 mt-1">
                Review and synchronize locally stored field records
              </p>
            </div>

            <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-500">
              ● Online
            </span>
          </div>

          {/* SYNC PROGRESS */}
          <div
            className={`p-5 rounded-xl border mb-5 ${
              isDarkMode
                ? "bg-slate-900 border-slate-700"
                : "bg-slate-50 border-slate-200"
            }`}
          >
            <div className="flex justify-between mb-3">
              <span className="text-sm font-bold">
                Current Sync Progress
              </span>

              <span className="text-sm font-bold text-sky-400">
                92%
              </span>
            </div>

            <div className="w-full h-3 bg-slate-700 rounded-full overflow-hidden">
              <div className="h-full w-[92%] bg-sky-500 rounded-full"></div>
            </div>

            <p className="text-xs text-slate-500 mt-3">
              124 of 132 local records synchronized
            </p>
          </div>

          {/* PENDING RECORDS */}
          <h3 className="font-bold mb-3">
            Pending Records
          </h3>

          <div className="space-y-3">
            <div
              className={`flex items-center justify-between p-4 rounded-lg border ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700"
                  : "bg-slate-50 border-slate-200"
              }`}
            >
              <div>
                <p className="font-bold">Survey No. 121</p>
                <p className="text-xs text-slate-500">
                  Boundary inspection record
                </p>
              </div>

              <span className="text-amber-500 text-xs font-bold">
                Pending
              </span>
            </div>

            <div
              className={`flex items-center justify-between p-4 rounded-lg border ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700"
                  : "bg-slate-50 border-slate-200"
              }`}
            >
              <div>
                <p className="font-bold">Survey No. 120</p>
                <p className="text-xs text-slate-500">
                  Field classification update
                </p>
              </div>

              <span className="text-amber-500 text-xs font-bold">
                Pending
              </span>
            </div>

            <div
              className={`flex items-center justify-between p-4 rounded-lg border ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700"
                  : "bg-slate-50 border-slate-200"
              }`}
            >
              <div>
                <p className="font-bold">Survey No. 118</p>
                <p className="text-xs text-slate-500">
                  Owner verification
                </p>
              </div>

              <span className="text-amber-500 text-xs font-bold">
                Pending
              </span>
            </div>
          </div>

          <button className="w-full mt-5 bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-lg">
            🔄 Sync All Pending Records
          </button>
        </div>

        {/* DEVICE / CONNECTION */}
        <div className={`${card} p-6 col-span-2`}>
          <h2
            className={`text-xl font-bold ${
              isDarkMode ? "text-white" : "text-slate-900"
            }`}
          >
            📱 Field Device
          </h2>

          <p className="text-sm text-slate-500 mt-1 mb-6">
            Offline data storage status
          </p>

          <div className="space-y-5">

            <div className="flex justify-between">
              <span className="text-slate-400">
                Connection
              </span>

              <span className="text-emerald-500 font-bold">
                Connected
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">
                Local Storage
              </span>

              <span className="font-bold">
                68%
              </span>
            </div>

            <div className="w-full h-2 bg-slate-700 rounded-full">
              <div className="w-[68%] h-full bg-sky-500 rounded-full"></div>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">
                Offline Records
              </span>

              <span className="font-bold text-amber-500">
                8
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">
                Last Successful Sync
              </span>

              <span className="font-bold">
                11:42 AM
              </span>
            </div>

          </div>

          <div className="mt-7 p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
            <p className="text-emerald-500 font-bold text-sm">
              ✓ Data Safe
            </p>

            <p className="text-xs text-slate-500 mt-1">
              All locally stored records are protected until synchronization.
            </p>
          </div>

          <button className="w-full mt-5 border border-blue-500 text-blue-400 hover:bg-blue-500/10 font-bold py-3 rounded-lg">
            View Sync History
          </button>
        </div>
      </div>

      {/* SYNC HISTORY */}
      <div className={`${card} p-6`}>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2
              className={`text-xl font-bold ${
                isDarkMode ? "text-white" : "text-slate-900"
              }`}
            >
              🕐 Recent Sync Activity
            </h2>

            <p className="text-sm text-slate-500 mt-1">
              Latest synchronization events
            </p>
          </div>

          <button className="text-blue-400 font-bold text-sm">
            View Full History →
          </button>
        </div>

        <div className="grid grid-cols-4 gap-4">

          <div className="border-l-4 border-emerald-500 pl-4">
            <p className="text-xs text-slate-500">
              Today · 11:42 AM
            </p>

            <p className="font-bold mt-1">
              Sync Completed
            </p>

            <p className="text-xs text-emerald-500 mt-1">
              18 records uploaded
            </p>
          </div>

          <div className="border-l-4 border-blue-500 pl-4">
            <p className="text-xs text-slate-500">
              Today · 10:18 AM
            </p>

            <p className="font-bold mt-1">
              Field Data Received
            </p>

            <p className="text-xs text-blue-400 mt-1">
              12 records downloaded
            </p>
          </div>

          <div className="border-l-4 border-amber-500 pl-4">
            <p className="text-xs text-slate-500">
              Yesterday · 5:36 PM
            </p>

            <p className="font-bold mt-1">
              Offline Session
            </p>

            <p className="text-xs text-amber-500 mt-1">
              8 records stored locally
            </p>
          </div>

          <div className="border-l-4 border-sky-500 pl-4">
            <p className="text-xs text-slate-500">
              Yesterday · 4:12 PM
            </p>

            <p className="font-bold mt-1">
              Sync Completed
            </p>

            <p className="text-xs text-sky-400 mt-1">
              24 records synchronized
            </p>
          </div>

        </div>
      </div>

      {/* NOTICE */}
      <div className="mt-6 border-l-4 border-amber-500 bg-slate-800 p-5 rounded-r-xl">
        <h3 className="text-amber-500 font-bold">
          ⚠ Offline Mode Protection
        </h3>

        <p className="text-sm text-slate-400 mt-1">
          Field records can be captured without connectivity and will
          automatically synchronize when the device reconnects.
        </p>
      </div>
    </div>
  );
}

export default OfflineSync;