function Dashboard({ isDarkMode }) {
  return (
    <div className="space-y-6">

      {/* Page Header */}
      <div>
        <h1
          className={`text-2xl font-bold ${
            isDarkMode ? "text-white" : "text-slate-900"
          }`}
        >
          Village Dashboard — Malhaur
        </h1>

        <p className="text-sm text-slate-500 mt-1">
          Mohanlalganj Tehsil, Lucknow District
        </p>
      </div>

      {/* KPI CARDS */}
      <div className="grid grid-cols-4 gap-4">

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500">
            TOTAL VILLAGE PLOTS
          </p>
          <p className="text-3xl font-bold text-sky-500 mt-2">432</p>
          <p className="text-xs text-slate-500 mt-1">
            Assigned for acquisition
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500">
            VERIFIED PARCELS
          </p>
          <p className="text-3xl font-bold text-emerald-500 mt-2">318</p>
          <p className="text-xs text-slate-500 mt-1">
            74% of village plots
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500">
            PENDING SCRUTINY
          </p>
          <p className="text-3xl font-bold text-amber-500 mt-2">87</p>
          <p className="text-xs text-slate-500 mt-1">
            Documents requiring review
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500">
            ACTIVE DISPUTES
          </p>
          <p className="text-3xl font-bold text-red-500 mt-2">6</p>
          <p className="text-xs text-slate-500 mt-1">
            Requiring attention
          </p>
        </div>

      </div>

      {/* MAIN CONTENT */}
      <div className="grid grid-cols-5 gap-6">

        {/* PARCEL LEDGER */}
        <div
          className={`col-span-3 rounded-xl border p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >

          <div className="flex justify-between items-center mb-5">
            <div>
              <h2 className="font-bold text-lg">
                📋 Parcel Verification Ledger
              </h2>

              <p className="text-xs text-slate-500 mt-1">
                Village-level land record verification
              </p>
            </div>

            <button className="text-xs text-blue-500 font-bold">
              View All →
            </button>
          </div>

          <div className="flex gap-2 mb-4">
            <input
              type="text"
              placeholder="Search survey no. or landowner..."
              className={`flex-1 px-3 py-2 rounded-lg border text-xs outline-none ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700"
                  : "bg-slate-50 border-slate-300"
              }`}
            />

            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold">
              Filter
            </button>
          </div>

          <table className="w-full text-sm">

            <thead className="text-xs text-slate-500 border-b border-slate-700">
              <tr>
                <th className="text-left py-3">Survey No.</th>
                <th className="text-left py-3">Landowner</th>
                <th className="text-left py-3">Area</th>
                <th className="text-left py-3">Classification</th>
                <th className="text-left py-3">Status</th>
              </tr>
            </thead>

            <tbody>

              <tr className="border-b border-slate-700/50">
                <td className="py-3 font-bold text-sky-500">112</td>
                <td>Ram Prakash</td>
                <td>0.582 Ha</td>
                <td>Agricultural</td>
                <td>
                  <span className="px-2 py-1 rounded bg-emerald-500/20 text-emerald-500 text-xs font-bold">
                    Verified
                  </span>
                </td>
              </tr>

              <tr className="border-b border-slate-700/50">
                <td className="py-3 font-bold text-sky-500">113</td>
                <td>Sushila Devi</td>
                <td>0.410 Ha</td>
                <td>Residential</td>
                <td>
                  <span className="px-2 py-1 rounded bg-amber-500/20 text-amber-500 text-xs font-bold">
                    Pending
                  </span>
                </td>
              </tr>

              <tr className="border-b border-slate-700/50">
                <td className="py-3 font-bold text-sky-500">115</td>
                <td>Ramesh Yadav</td>
                <td>0.900 Ha</td>
                <td>Agricultural</td>
                <td>
                  <span className="px-2 py-1 rounded bg-red-500/20 text-red-500 text-xs font-bold">
                    Missing RoR
                  </span>
                </td>
              </tr>

              <tr className="border-b border-slate-700/50">
                <td className="py-3 font-bold text-sky-500">117</td>
                <td>Geeta Singh</td>
                <td>0.750 Ha</td>
                <td>Agricultural</td>
                <td>
                  <span className="px-2 py-1 rounded bg-amber-500/20 text-amber-500 text-xs font-bold">
                    Pending
                  </span>
                </td>
              </tr>

              <tr>
                <td className="py-3 font-bold text-sky-500">121</td>
                <td>Vijay Pal</td>
                <td>0.920 Ha</td>
                <td>Residential</td>
                <td>
                  <span className="px-2 py-1 rounded bg-red-500/20 text-red-500 text-xs font-bold">
                    Boundary Clash
                  </span>
                </td>
              </tr>

            </tbody>
          </table>

        </div>

        {/* RIGHT SIDE */}
        <div className="col-span-2 space-y-6">

          {/* MAP */}
          <div
            className={`rounded-xl border p-5 ${
              isDarkMode
                ? "bg-slate-800 border-slate-700"
                : "bg-white border-slate-200 shadow-sm"
            }`}
          >

            <div className="flex justify-between mb-4">
              <h2 className="font-bold">
                🗺️ Cadastral Map View
              </h2>

              <button className="text-xs text-blue-500 font-bold">
                Full Map
              </button>
            </div>

            <div
              className={`h-64 rounded-lg flex items-center justify-center border ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700"
                  : "bg-slate-100 border-slate-300"
              }`}
            >
              <div className="text-center">
                <p className="text-4xl mb-3">🗺️</p>

                <p className="text-sm font-bold">
                  Cadastral Map
                </p>

                <p className="text-xs text-slate-500 mt-1">
                  GIS / Mapbox / Leaflet integration
                </p>
              </div>
            </div>

            <div className="flex gap-5 mt-4 text-xs">
              <span className="text-emerald-500">● Verified</span>
              <span className="text-amber-500">● Pending</span>
              <span className="text-red-500">● Boundary Clash</span>
            </div>

          </div>

          {/* SURVEY OFFICER PROGRESS */}
          <div
            className={`rounded-xl border p-5 ${
              isDarkMode
                ? "bg-slate-800 border-slate-700"
                : "bg-white border-slate-200 shadow-sm"
            }`}
          >

            <div className="flex justify-between items-center mb-4">

              <div>
                <h2 className="font-bold">
                  👥 Survey Officers
                </h2>

                <p className="text-xs text-slate-500">
                  Field activity progress
                </p>
              </div>

              <button className="text-xs text-blue-500 font-bold">
                View →
              </button>

            </div>

            <div className="space-y-4">

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Ramesh Kumar</span>
                  <span>80%</span>
                </div>

                <div className="h-2 bg-slate-700 rounded-full">
                  <div className="h-2 bg-emerald-500 rounded-full w-[80%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Savitri Devi</span>
                  <span>60%</span>
                </div>

                <div className="h-2 bg-slate-700 rounded-full">
                  <div className="h-2 bg-blue-500 rounded-full w-[60%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Iqbal Khan</span>
                  <span>50%</span>
                </div>

                <div className="h-2 bg-slate-700 rounded-full">
                  <div className="h-2 bg-amber-500 rounded-full w-[50%]" />
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>

      {/* BOTTOM SECTION */}
      <div className="grid grid-cols-2 gap-6">

        {/* STATUTORY ALERTS */}
        <div
          className={`rounded-xl border p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >

          <div className="flex justify-between mb-4">
            <h2 className="font-bold">
              ⚠️ Statutory Alerts
            </h2>

            <span className="text-xs text-blue-500">
              View All
            </span>
          </div>

          <div className="space-y-3">

            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20">
              <p className="text-sm font-bold text-red-500">
                Missing Records
              </p>

              <p className="text-xs text-slate-500 mt-1">
                14 plots lack Record of Rights (RoR).
              </p>
            </div>

            <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
              <p className="text-sm font-bold text-amber-500">
                NOC Countdown
              </p>

              <p className="text-xs text-slate-500 mt-1">
                5 days remaining for Section 11 clearance.
              </p>
            </div>

            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20">
              <p className="text-sm font-bold text-red-500">
                Dispute Holds
              </p>

              <p className="text-xs text-slate-500 mt-1">
                3 injunctions currently freezing local activity.
              </p>
            </div>

          </div>

        </div>

        {/* RECENT ACTIVITIES */}
        <div
          className={`rounded-xl border p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >

          <div className="flex justify-between mb-4">
            <h2 className="font-bold">
              🕒 Recent Field Activities
            </h2>

            <button className="text-xs text-blue-500 font-bold">
              View Log →
            </button>
          </div>

          <div className="space-y-3">

            <div className="flex justify-between items-center border-b border-slate-700/50 pb-3">
              <div>
                <p className="text-sm font-bold">
                  Ramesh Kumar
                </p>

                <p className="text-xs text-slate-500">
                  Boundary measurement — Survey 115
                </p>
              </div>

              <span className="text-xs text-emerald-500">
                Completed
              </span>
            </div>

            <div className="flex justify-between items-center border-b border-slate-700/50 pb-3">
              <div>
                <p className="text-sm font-bold">
                  Savitri Devi
                </p>

                <p className="text-xs text-slate-500">
                  Owner verification — Survey 118
                </p>
              </div>

              <span className="text-xs text-blue-500">
                Completed
              </span>
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-bold">
                  Iqbal Khan
                </p>

                <p className="text-xs text-slate-500">
                  Land-use classification — Survey 120
                </p>
              </div>

              <span className="text-xs text-amber-500">
                In Progress
              </span>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
}

export default Dashboard;