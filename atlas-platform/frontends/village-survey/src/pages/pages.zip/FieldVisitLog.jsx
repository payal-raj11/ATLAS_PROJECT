function FieldVisitLog({ isDarkMode }) {
  const visits = [
    {
      date: "12-09-2025",
      officer: "Ramesh Kumar",
      survey: "115",
      landowner: "Ramesh Yadav",
      activity: "Boundary Measurement",
      status: "Completed",
    },
    {
      date: "11-09-2025",
      officer: "Savitri Devi",
      survey: "118",
      landowner: "Rajesh Kumar",
      activity: "Owner Verification",
      status: "Completed",
    },
    {
      date: "10-09-2025",
      officer: "Iqbal Khan",
      survey: "120",
      landowner: "Sita Devi",
      activity: "Land Classification",
      status: "In Progress",
    },
    {
      date: "09-09-2025",
      officer: "Anil Verma",
      survey: "121",
      landowner: "Vijay Pal",
      activity: "Boundary Inspection",
      status: "Issue Found",
    },
    {
      date: "08-09-2025",
      officer: "Ramesh Kumar",
      survey: "112",
      landowner: "Ram Prakash",
      activity: "Field Measurement",
      status: "Completed",
    },
  ];

  return (
    <div className="space-y-6">

      {/* PAGE HEADER */}
      <div>
        <h1
          className={`text-3xl font-bold ${
            isDarkMode ? "text-white" : "text-slate-900"
          }`}
        >
          Field Visit Log
        </h1>

        <p className="text-slate-500 mt-1">
          Track field inspections, measurements, evidence and visit outcomes
        </p>
      </div>

      {/* KPI CARDS */}
      <div className="grid grid-cols-4 gap-4">

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-400 uppercase">
            Total Visits
          </p>

          <p className="text-3xl font-bold text-sky-400 mt-2">
            56
          </p>

          <p className="text-xs text-slate-500 mt-1">
            This acquisition cycle
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-400 uppercase">
            Completed
          </p>

          <p className="text-3xl font-bold text-emerald-500 mt-2">
            43
          </p>

          <p className="text-xs text-slate-500 mt-1">
            Visits successfully closed
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-400 uppercase">
            Pending Visits
          </p>

          <p className="text-3xl font-bold text-amber-500 mt-2">
            10
          </p>

          <p className="text-xs text-slate-500 mt-1">
            Awaiting field action
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-400 uppercase">
            Issues Found
          </p>

          <p className="text-3xl font-bold text-red-500 mt-2">
            3
          </p>

          <p className="text-xs text-slate-500 mt-1">
            Require further verification
          </p>
        </div>

      </div>

      {/* MAIN GRID */}
      <div className="grid grid-cols-3 gap-6">

        {/* VISIT REGISTER */}
        <div
          className={`col-span-2 border rounded-xl p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >

          <div className="flex items-center justify-between mb-5">

            <div>
              <h2
                className={`text-xl font-bold ${
                  isDarkMode ? "text-white" : "text-slate-900"
                }`}
              >
                📍 Recent Field Visits
              </h2>

              <p className="text-sm text-slate-500 mt-1">
                Field inspections and survey activities
              </p>
            </div>

            <button className="text-blue-400 text-sm font-bold">
              View All →
            </button>

          </div>

          {/* SEARCH */}
          <div className="flex gap-3 mb-5">

            <input
              type="text"
              placeholder="Search survey no., officer or landowner..."
              className={`flex-1 px-4 py-3 rounded-lg border outline-none text-sm ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700 text-white placeholder-slate-500"
                  : "bg-slate-50 border-slate-300 text-slate-900"
              }`}
            />

            <button className="px-6 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold text-sm">
              Filter
            </button>

          </div>

          {/* TABLE */}
          <div className="overflow-x-auto">

            <table className="w-full text-left text-sm">

              <thead>
                <tr
                  className={`border-b ${
                    isDarkMode
                      ? "border-slate-700 text-slate-400"
                      : "border-slate-200 text-slate-500"
                  }`}
                >
                  <th className="py-3">Date</th>
                  <th className="py-3">Officer</th>
                  <th className="py-3">Survey No.</th>
                  <th className="py-3">Activity</th>
                  <th className="py-3">Status</th>
                </tr>
              </thead>

              <tbody>

                {visits.map((visit) => (
                  <tr
                    key={`${visit.date}-${visit.survey}`}
                    className={`border-b ${
                      isDarkMode
                        ? "border-slate-700/60"
                        : "border-slate-200"
                    }`}
                  >

                    <td className="py-4 text-slate-400">
                      {visit.date}
                    </td>

                    <td className="py-4">
                      <div>
                        <p
                          className={`font-bold ${
                            isDarkMode
                              ? "text-white"
                              : "text-slate-900"
                          }`}
                        >
                          {visit.officer}
                        </p>

                        <p className="text-xs text-slate-500">
                          {visit.landowner}
                        </p>
                      </div>
                    </td>

                    <td className="py-4 font-bold text-sky-400">
                      {visit.survey}
                    </td>

                    <td className="py-4">
                      {visit.activity}
                    </td>

                    <td className="py-4">

                      <span
                        className={`px-2 py-1 rounded text-xs font-bold ${
                          visit.status === "Completed"
                            ? "bg-emerald-500/20 text-emerald-400"
                            : visit.status === "In Progress"
                            ? "bg-blue-500/20 text-blue-400"
                            : "bg-red-500/20 text-red-400"
                        }`}
                      >
                        {visit.status}
                      </span>

                    </td>

                  </tr>
                ))}

              </tbody>

            </table>

          </div>

          {/* ADD VISIT */}
          <div className="flex justify-end mt-5">

            <button className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold text-sm">
              + Add New Visit
            </button>

          </div>

        </div>

        {/* SELECTED VISIT */}
        <div
          className={`border rounded-xl p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >

          <div className="flex items-center justify-between mb-5">

            <div>
              <h2
                className={`text-xl font-bold ${
                  isDarkMode ? "text-white" : "text-slate-900"
                }`}
              >
                📋 Visit Details
              </h2>

              <p className="text-sm text-slate-500 mt-1">
                Selected field inspection
              </p>
            </div>

            <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400">
              Completed
            </span>

          </div>

          {/* VISIT INFORMATION */}
          <div className="space-y-5">

            <div className="flex justify-between border-b border-slate-700 pb-4">
              <span className="text-slate-500">
                Survey No.
              </span>

              <span className="font-bold text-sky-400">
                115
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700 pb-4">
              <span className="text-slate-500">
                Landowner
              </span>

              <span className="font-bold text-white">
                Ramesh Yadav
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700 pb-4">
              <span className="text-slate-500">
                Field Officer
              </span>

              <span className="font-bold text-white">
                Ramesh Kumar
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700 pb-4">
              <span className="text-slate-500">
                Visit Date
              </span>

              <span className="font-bold text-white">
                12-09-2025
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700 pb-4">
              <span className="text-slate-500">
                Activity
              </span>

              <span className="font-bold text-white text-right">
                Boundary Measurement
              </span>
            </div>

          </div>

          {/* FIELD RESULT */}
          <div className="mt-5">

            <h3 className="text-sm font-bold text-slate-300 mb-2">
              Field Result
            </h3>

            <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/30">

              <p className="text-sm text-emerald-400 font-bold">
                ✓ Boundary verified
              </p>

              <p className="text-xs text-slate-400 mt-2">
                Field measurements match the available cadastral record.
              </p>

            </div>

          </div>

          {/* ACTION BUTTONS */}
          <div className="mt-5 space-y-2">

            <button className="w-full py-3 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm">
              📷 View Field Evidence
            </button>

            <button className="w-full py-3 rounded-lg border border-blue-500 text-blue-400 hover:bg-blue-500/10 font-bold text-sm">
              📝 View Inspection Notes
            </button>

          </div>

        </div>

      </div>

      {/* FIELD ACTIVITY TIMELINE */}
      <div
        className={`border rounded-xl p-5 ${
          isDarkMode
            ? "bg-slate-800 border-slate-700"
            : "bg-white border-slate-200 shadow-sm"
        }`}
      >

        <div className="flex items-center justify-between mb-5">

          <div>
            <h2
              className={`text-xl font-bold ${
                isDarkMode ? "text-white" : "text-slate-900"
              }`}
            >
              🕒 Field Activity Timeline
            </h2>

            <p className="text-sm text-slate-500 mt-1">
              Latest activities recorded by survey officers
            </p>
          </div>

          <button className="text-blue-400 text-sm font-bold">
            View Complete Log →
          </button>

        </div>

        <div className="grid grid-cols-4 gap-5">

          <div className="border-l-4 border-emerald-500 pl-4">

            <p className="text-xs text-slate-500">
              12 Sep 2025
            </p>

            <h3 className="font-bold text-white mt-1">
              Boundary Measurement
            </h3>

            <p className="text-xs text-slate-500 mt-1">
              Survey 115 · Ramesh Kumar
            </p>

            <p className="text-xs text-emerald-400 mt-2 font-bold">
              Completed
            </p>

          </div>

          <div className="border-l-4 border-blue-500 pl-4">

            <p className="text-xs text-slate-500">
              11 Sep 2025
            </p>

            <h3 className="font-bold text-white mt-1">
              Owner Verification
            </h3>

            <p className="text-xs text-slate-500 mt-1">
              Survey 118 · Savitri Devi
            </p>

            <p className="text-xs text-blue-400 mt-2 font-bold">
              Completed
            </p>

          </div>

          <div className="border-l-4 border-amber-500 pl-4">

            <p className="text-xs text-slate-500">
              10 Sep 2025
            </p>

            <h3 className="font-bold text-white mt-1">
              Land Classification
            </h3>

            <p className="text-xs text-slate-500 mt-1">
              Survey 120 · Iqbal Khan
            </p>

            <p className="text-xs text-amber-400 mt-2 font-bold">
              In Progress
            </p>

          </div>

          <div className="border-l-4 border-red-500 pl-4">

            <p className="text-xs text-slate-500">
              09 Sep 2025
            </p>

            <h3 className="font-bold text-white mt-1">
              Boundary Inspection
            </h3>

            <p className="text-xs text-slate-500 mt-1">
              Survey 121 · Anil Verma
            </p>

            <p className="text-xs text-red-400 mt-2 font-bold">
              Issue Found
            </p>

          </div>

        </div>

      </div>

      {/* FIELD EVIDENCE NOTICE */}
      <div className="border-l-4 border-blue-500 bg-slate-800 rounded-r-xl p-4">

        <h3 className="text-blue-400 font-bold text-sm mb-1">
          📍 Field Evidence Status
        </h3>

        <p className="text-xs text-slate-400">
          Recent field visits are being recorded with inspection notes,
          measurements and supporting photographs for parcel verification.
        </p>

      </div>

    </div>
  );
}

export default FieldVisitLog;