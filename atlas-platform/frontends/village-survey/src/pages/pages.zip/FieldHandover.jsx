import { useState } from "react";

function FieldHandover({ isDarkMode }) {
  const [selectedParcel, setSelectedParcel] = useState(0);

  const parcels = [
    {
      survey: "112",
      landowner: "Ram Prakash",
      area: "0.582 Ha",
      compensation: "Approved",
      possession: "Ready",
      officer: "Ramesh Kumar",
      date: "12-09-2025",
    },
    {
      survey: "113",
      landowner: "Sushila Devi",
      area: "0.410 Ha",
      compensation: "Pending",
      possession: "On Hold",
      officer: "Savitri Devi",
      date: "15-09-2025",
    },
    {
      survey: "116",
      landowner: "Ramesh Yadav",
      area: "0.750 Ha",
      compensation: "Approved",
      possession: "Scheduled",
      officer: "Iqbal Khan",
      date: "18-09-2025",
    },
    {
      survey: "118",
      landowner: "Rajesh Kumar",
      area: "0.680 Ha",
      compensation: "Approved",
      possession: "Ready",
      officer: "Ramesh Kumar",
      date: "20-09-2025",
    },
  ];

  const active = parcels[selectedParcel];

  return (
    <div className="space-y-6">

      {/* PAGE HEADER */}
      <div>
        <h1
          className={`text-3xl font-bold ${
            isDarkMode ? "text-white" : "text-slate-900"
          }`}
        >
          Field Handover / Possession
        </h1>

        <p className="text-slate-500 mt-1">
          Track possession readiness, handover documents and field completion
        </p>
      </div>

      {/* KPI CARDS */}
      <div className="grid grid-cols-4 gap-4">

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500 uppercase">
            Ready for Possession
          </p>

          <p className="text-3xl font-bold text-emerald-500 mt-2">
            18
          </p>

          <p className="text-xs text-slate-500 mt-1">
            All clearances completed
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500 uppercase">
            Scheduled
          </p>

          <p className="text-3xl font-bold text-blue-500 mt-2">
            9
          </p>

          <p className="text-xs text-slate-500 mt-1">
            Upcoming field handovers
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500 uppercase">
            Compensation Pending
          </p>

          <p className="text-3xl font-bold text-amber-500 mt-2">
            7
          </p>

          <p className="text-xs text-slate-500 mt-1">
            Cannot proceed to possession
          </p>
        </div>

        <div
          className={`p-5 rounded-xl border ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >
          <p className="text-xs font-bold text-slate-500 uppercase">
            Completed
          </p>

          <p className="text-3xl font-bold text-sky-400 mt-2">
            11
          </p>

          <p className="text-xs text-slate-500 mt-1">
            Possession records closed
          </p>
        </div>

      </div>

      {/* MAIN WORKSPACE */}
      <div className="grid grid-cols-5 gap-6">

        {/* LEFT TABLE */}
        <div
          className={`col-span-3 rounded-xl border p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >

          <div className="flex items-center justify-between mb-5">

            <div>
              <h2
                className={`text-xl font-bold ${
                  isDarkMode ? "text-white" : "text-slate-900"
                }`}
              >
                🏠 Possession Register
              </h2>

              <p className="text-xs text-slate-500 mt-1">
                Parcels cleared for field handover
              </p>
            </div>

            <button className="text-blue-500 text-sm font-bold">
              View All →
            </button>

          </div>

          {/* SEARCH */}
          <div className="flex gap-3 mb-5">

            <input
              type="text"
              placeholder="Search survey no. or landowner..."
              className={`flex-1 rounded-lg border px-4 py-2 text-sm outline-none ${
                isDarkMode
                  ? "bg-slate-900 border-slate-700 text-white placeholder:text-slate-500"
                  : "bg-slate-50 border-slate-300 text-slate-900"
              }`}
            />

            <button className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold">
              Filter
            </button>

          </div>

          {/* TABLE */}
          <table className="w-full text-left text-sm">

            <thead className="text-xs text-slate-500 uppercase">

              <tr className="border-b border-slate-700/50">

                <th className="pb-3">
                  Survey No.
                </th>

                <th className="pb-3">
                  Landowner
                </th>

                <th className="pb-3">
                  Area
                </th>

                <th className="pb-3">
                  Compensation
                </th>

                <th className="pb-3">
                  Possession
                </th>

              </tr>

            </thead>

            <tbody>

              {parcels.map((parcel, index) => (

                <tr
                  key={parcel.survey}
                  onClick={() => setSelectedParcel(index)}
                  className={`border-b border-slate-700/40 cursor-pointer transition ${
                    selectedParcel === index
                      ? "bg-blue-500/10"
                      : "hover:bg-slate-700/20"
                  }`}
                >

                  <td className="py-4 font-bold text-blue-400">
                    {parcel.survey}
                  </td>

                  <td className="py-4">
                    {parcel.landowner}
                  </td>

                  <td className="py-4">
                    {parcel.area}
                  </td>

                  <td className="py-4">

                    <span
                      className={`px-2 py-1 rounded text-xs font-bold ${
                        parcel.compensation === "Approved"
                          ? "bg-emerald-500/20 text-emerald-500"
                          : "bg-amber-500/20 text-amber-500"
                      }`}
                    >
                      {parcel.compensation}
                    </span>

                  </td>

                  <td className="py-4">

                    <span
                      className={`px-2 py-1 rounded text-xs font-bold ${
                        parcel.possession === "Ready"
                          ? "bg-emerald-500/20 text-emerald-500"
                          : parcel.possession === "Scheduled"
                          ? "bg-blue-500/20 text-blue-400"
                          : "bg-amber-500/20 text-amber-500"
                      }`}
                    >
                      {parcel.possession}
                    </span>

                  </td>

                </tr>

              ))}

            </tbody>

          </table>

          {/* ALERT */}
          <div className="mt-5 border border-amber-500/40 bg-amber-500/10 rounded-lg p-4">

            <p className="text-amber-500 font-bold text-sm">
              ⚠ Possession Prerequisite
            </p>

            <p className="text-xs text-slate-500 mt-1">
              Compensation approval, statutory clearance and field verification
              must be completed before possession is recorded.
            </p>

          </div>

        </div>

        {/* RIGHT DETAILS */}
        <div
          className={`col-span-2 rounded-xl border p-5 ${
            isDarkMode
              ? "bg-slate-800 border-slate-700"
              : "bg-white border-slate-200 shadow-sm"
          }`}
        >

          <div className="flex items-center justify-between mb-5">

            <div>
              <h2
                className={`text-xl font-bold ${
                  isDarkMode ? "text-white" : "text-slate-900"
                }`}
              >
                📋 Handover Details
              </h2>

              <p className="text-xs text-slate-500 mt-1">
                Selected parcel
              </p>
            </div>

            <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-500">
              {active.possession}
            </span>

          </div>

          {/* DETAILS */}
          <div className="space-y-4">

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Survey No.
              </span>

              <span className="font-bold text-blue-400">
                {active.survey}
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Landowner
              </span>

              <span className="font-bold">
                {active.landowner}
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Official Area
              </span>

              <span className="font-bold">
                {active.area}
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Compensation
              </span>

              <span
                className={
                  active.compensation === "Approved"
                    ? "font-bold text-emerald-500"
                    : "font-bold text-amber-500"
                }
              >
                {active.compensation}
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Field Officer
              </span>

              <span className="font-bold">
                {active.officer}
              </span>
            </div>

            <div className="flex justify-between border-b border-slate-700/40 pb-3">
              <span className="text-sm text-slate-500">
                Handover Date
              </span>

              <span className="font-bold">
                {active.date}
              </span>
            </div>

          </div>

          {/* CHECKLIST */}
          <div className="mt-5">

            <h3 className="text-sm font-bold mb-3">
              Handover Checklist
            </h3>

            <div className="space-y-2">

              <div className="flex items-center gap-3 text-sm">
                <span className="w-6 h-6 rounded bg-emerald-500 flex items-center justify-center text-white">
                  ✓
                </span>

                Land record verified
              </div>

              <div className="flex items-center gap-3 text-sm">
                <span className="w-6 h-6 rounded bg-emerald-500 flex items-center justify-center text-white">
                  ✓
                </span>

                Compensation approved
              </div>

              <div className="flex items-center gap-3 text-sm">
                <span className="w-6 h-6 rounded bg-emerald-500 flex items-center justify-center text-white">
                  ✓
                </span>

                Field measurement completed
              </div>

              <div className="flex items-center gap-3 text-sm">
                <span className="w-6 h-6 rounded bg-emerald-500 flex items-center justify-center text-white">
                  ✓
                </span>

                Possession notice issued
              </div>

            </div>

          </div>

          {/* ACTIONS */}
          <div className="mt-6 space-y-2">

            <button className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 rounded-lg text-sm">
              📄 View Handover Documents
            </button>

            <button className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-lg text-sm">
              ✓ Record Possession
            </button>

            <button className="w-full border border-blue-500 text-blue-400 hover:bg-blue-500/10 font-bold py-2.5 rounded-lg text-sm">
              📤 Export Possession Record
            </button>

          </div>

        </div>

      </div>

      {/* HANDOVER PROGRESS */}
      <div
        className={`rounded-xl border p-5 ${
          isDarkMode
            ? "bg-slate-800 border-slate-700"
            : "bg-white border-slate-200 shadow-sm"
        }`}
      >

        <div className="flex items-center justify-between mb-5">

          <div>
            <h2
              className={`text-xl font-bold ${
                isDarkMode ? "text-white" : "text-slate-900"
              }`}
            >
              📍 Field Handover Progress
            </h2>

            <p className="text-xs text-slate-500 mt-1">
              Current possession workflow status
            </p>
          </div>

          <button className="text-blue-500 text-sm font-bold">
            View Handover Log →
          </button>

        </div>

        <div className="grid grid-cols-4 gap-6">

          <div className="border-l-4 border-emerald-500 pl-4">

            <p className="text-xs text-slate-500">
              Step 1
            </p>

            <p className="font-bold mt-1">
              Land Verified
            </p>

            <p className="text-xs text-emerald-500 mt-1">
              Completed
            </p>

          </div>

          <div className="border-l-4 border-emerald-500 pl-4">

            <p className="text-xs text-slate-500">
              Step 2
            </p>

            <p className="font-bold mt-1">
              Compensation
            </p>

            <p className="text-xs text-emerald-500 mt-1">
              Approved
            </p>

          </div>

          <div className="border-l-4 border-blue-500 pl-4">

            <p className="text-xs text-slate-500">
              Step 3
            </p>

            <p className="font-bold mt-1">
              Field Handover
            </p>

            <p className="text-xs text-blue-400 mt-1">
              Scheduled
            </p>

          </div>

          <div className="border-l-4 border-slate-600 pl-4">

            <p className="text-xs text-slate-500">
              Step 4
            </p>

            <p className="font-bold mt-1">
              Possession Recorded
            </p>

            <p className="text-xs text-slate-500 mt-1">
              Awaiting completion
            </p>

          </div>

        </div>

      </div>

    </div>
  );
}

export default FieldHandover;