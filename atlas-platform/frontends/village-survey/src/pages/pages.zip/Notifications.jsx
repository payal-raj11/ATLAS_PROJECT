function Notifications({ isDarkMode }) {
  const card = `rounded-xl border p-5 ${
    isDarkMode
      ? "bg-slate-800 border-slate-700"
      : "bg-white border-slate-200 shadow-sm"
  }`;

  return (
    <div className="space-y-5">

      {/* PAGE HEADER */}
      <div>
        <h1
          className={`text-2xl font-bold ${
            isDarkMode ? "text-white" : "text-slate-900"
          }`}
        >
          Notifications & Objections
        </h1>

        <p className="text-sm text-slate-500 mt-1">
          Manage statutory notifications, Gram Sabha NOC and public objections
        </p>
      </div>

      {/* KPI CARDS */}
      <div className="grid grid-cols-4 gap-4">

        <div className={`${card} border-blue-500/30`}>
          <p className="text-xs font-bold text-slate-500">
            PLOTS NOTIFIED
          </p>
          <p className="text-3xl font-bold text-blue-500 mt-2">
            28
          </p>
          <p className="text-xs text-slate-500">
            under Section 11
          </p>
        </div>

        <div className={`${card} border-emerald-500/30`}>
          <p className="text-xs font-bold text-slate-500">
            GRAM SABHA MEETING
          </p>
          <p className="text-3xl font-bold text-emerald-500 mt-2">
            1
          </p>
          <p className="text-xs text-emerald-500">
            Completed
          </p>
        </div>

        <div className={`${card} border-amber-500/30`}>
          <p className="text-xs font-bold text-slate-500">
            OBJECTIONS RECEIVED
          </p>
          <p className="text-3xl font-bold text-amber-500 mt-2">
            5
          </p>
          <p className="text-xs text-amber-500">
            2 Pending Review
          </p>
        </div>

        <div className={`${card} border-red-500/30`}>
          <p className="text-xs font-bold text-slate-500">
            NOC DEADLINE
          </p>
          <p className="text-3xl font-bold text-red-500 mt-2">
            3
          </p>
          <p className="text-xs text-red-500">
            days remaining
          </p>
        </div>

      </div>

      {/* ALERTS + DEADLINES */}
      <div className="grid grid-cols-2 gap-5">

        {/* STATUTORY ALERTS */}
        <div className={card}>

          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-bold">
              ⚠️ Statutory Alerts
            </h2>

            <button className="text-blue-500 text-xs font-bold">
              View All →
            </button>
          </div>

          <div className="space-y-3">

            <div className="p-4 rounded-lg border border-red-500/40 bg-red-500/10">
              <div className="flex justify-between">
                <p className="font-bold text-red-500">
                  Missing Records
                </p>
                <span className="text-xs text-slate-500">
                  12 Sep 2025
                </span>
              </div>

              <p className="text-xs text-slate-500 mt-1">
                14 plots lack Record of Rights (RoR) before notification.
              </p>
            </div>

            <div className="p-4 rounded-lg border border-orange-500/40 bg-orange-500/10">
              <div className="flex justify-between">
                <p className="font-bold text-orange-500">
                  Dispute Holds
                </p>
                <span className="text-xs text-slate-500">
                  10 Sep 2025
                </span>
              </div>

              <p className="text-xs text-slate-500 mt-1">
                3 injunctions freezing local activity.
              </p>
            </div>

            <div className="p-4 rounded-lg border border-amber-500/40 bg-amber-500/10">
              <div className="flex justify-between">
                <p className="font-bold text-amber-500">
                  NOC Countdown
                </p>
                <span className="text-xs text-slate-500">
                  12 Sep 2025
                </span>
              </div>

              <p className="text-xs text-slate-500 mt-1">
                5 days remaining for Gram Panchayat Section 11 clearance.
              </p>
            </div>

          </div>

        </div>

        {/* UPCOMING DEADLINES */}
        <div className={card}>

          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-bold">
              📅 Upcoming Deadlines
            </h2>

            <button className="text-blue-500 text-xs font-bold">
              View Calendar →
            </button>
          </div>

          <div className="space-y-3">

            <div className="flex justify-between items-center p-4 rounded-lg border border-slate-700">
              <div>
                <p className="font-bold text-sm">
                  Gram Sabha NOC Submission
                </p>

                <p className="text-xs text-slate-500">
                  For Malhaur Village
                </p>
              </div>

              <div className="text-right">
                <p className="text-sm font-bold">
                  15 Sep 2025
                </p>

                <p className="text-xs text-red-500">
                  3 days left
                </p>
              </div>
            </div>

            <div className="flex justify-between items-center p-4 rounded-lg border border-slate-700">
              <div>
                <p className="font-bold text-sm">
                  Public Objection Hearing
                </p>

                <p className="text-xs text-slate-500">
                  At Tehsil Office, Mohanlalganj
                </p>
              </div>

              <div className="text-right">
                <p className="text-sm font-bold">
                  20 Sep 2025
                </p>

                <p className="text-xs text-red-500">
                  8 days left
                </p>
              </div>
            </div>

            <div className="flex justify-between items-center p-4 rounded-lg border border-slate-700">
              <div>
                <p className="font-bold text-sm">
                  Finalize Objection Report
                </p>

                <p className="text-xs text-slate-500">
                  Submit to SDM
                </p>
              </div>

              <div className="text-right">
                <p className="text-sm font-bold">
                  25 Sep 2025
                </p>

                <p className="text-xs text-slate-500">
                  13 days left
                </p>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* OBJECTIONS + GRAM SABHA */}
      <div className="grid grid-cols-5 gap-5">

        {/* PUBLIC OBJECTIONS */}
        <div className={`col-span-3 ${card}`}>

          <div className="flex justify-between items-center mb-4">

            <h2 className="text-lg font-bold">
              Public Objections
            </h2>

            <div className="flex gap-2">

              <input
                type="text"
                placeholder="Search by name or survey no..."
                className={`px-3 py-2 rounded-lg border text-xs outline-none ${
                  isDarkMode
                    ? "bg-slate-900 border-slate-700"
                    : "bg-slate-50 border-slate-300"
                }`}
              />

              <button className="px-4 py-2 rounded-lg border border-blue-500 text-blue-500 text-xs font-bold">
                Filter
              </button>

            </div>

          </div>

          <table className="w-full text-sm">

            <thead className="text-xs text-slate-500 border-b border-slate-700">

              <tr>
                <th className="text-left py-3">Date</th>
                <th className="text-left py-3">Objector</th>
                <th className="text-left py-3">Survey No.</th>
                <th className="text-left py-3">Nature</th>
                <th className="text-left py-3">Status</th>
                <th className="text-left py-3">Action</th>
              </tr>

            </thead>

            <tbody>

              <tr className="border-b border-slate-700/50">
                <td className="py-3">12-09-2025</td>
                <td>Mohd. Arif</td>
                <td>115</td>
                <td>Boundary dispute</td>
                <td className="text-amber-500">Under Review</td>
                <td>
                  <button className="text-blue-500 font-bold">
                    View
                  </button>
                </td>
              </tr>

              <tr className="border-b border-slate-700/50">
                <td className="py-3">12-09-2025</td>
                <td>Sita Devi</td>
                <td>120</td>
                <td>Wrong ownership</td>
                <td className="text-emerald-500">Forwarded</td>
                <td>
                  <button className="text-blue-500 font-bold">
                    View
                  </button>
                </td>
              </tr>

              <tr className="border-b border-slate-700/50">
                <td className="py-3">11-09-2025</td>
                <td>Rajesh Kumar</td>
                <td>118</td>
                <td>Compensation issue</td>
                <td className="text-amber-500">Pending</td>
                <td>
                  <button className="text-blue-500 font-bold">
                    View
                  </button>
                </td>
              </tr>

              <tr className="border-b border-slate-700/50">
                <td className="py-3">10-09-2025</td>
                <td>Geeta Singh</td>
                <td>117</td>
                <td>Access to land</td>
                <td className="text-emerald-500">Resolved</td>
                <td>
                  <button className="text-blue-500 font-bold">
                    View
                  </button>
                </td>
              </tr>

              <tr>
                <td className="py-3">09-09-2025</td>
                <td>Ramesh Yadav</td>
                <td>116</td>
                <td>Land classification</td>
                <td className="text-amber-500">Pending</td>
                <td>
                  <button className="text-blue-500 font-bold">
                    View
                  </button>
                </td>
              </tr>

            </tbody>

          </table>

          <div className="flex justify-between items-center mt-5">

            <span className="text-xs text-slate-500">
              Showing 1–5 of 5 records
            </span>

            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold">
              + Add New Objection
            </button>

          </div>

        </div>

        {/* GRAM SABHA */}
        <div className={`col-span-2 ${card}`}>

          <div className="flex justify-between items-center">
            <h2 className="text-lg font-bold">
              Gram Sabha Meeting Details
            </h2>

            <button className="text-blue-500 text-xs font-bold">
              Edit
            </button>
          </div>

          <div className="space-y-4 mt-5">

            <div>
              <label className="text-xs text-slate-500">
                Meeting Date
              </label>

              <input
                type="text"
                defaultValue="12-09-2025"
                className={`w-full mt-1 p-2 rounded-lg border text-sm ${
                  isDarkMode
                    ? "bg-slate-900 border-slate-700"
                    : "bg-slate-50 border-slate-300"
                }`}
              />
            </div>

            <div>
              <label className="text-xs text-slate-500">
                Venue
              </label>

              <input
                type="text"
                defaultValue="Malhaur Panchayat Bhawan"
                className={`w-full mt-1 p-2 rounded-lg border text-sm ${
                  isDarkMode
                    ? "bg-slate-900 border-slate-700"
                    : "bg-slate-50 border-slate-300"
                }`}
              />
            </div>

            <div>
              <label className="text-xs text-slate-500">
                Chairperson
              </label>

              <input
                type="text"
                defaultValue="Gram Pradhan — Smt. Kavita Singh"
                className={`w-full mt-1 p-2 rounded-lg border text-sm ${
                  isDarkMode
                    ? "bg-slate-900 border-slate-700"
                    : "bg-slate-50 border-slate-300"
                }`}
              />
            </div>

            <div>
              <label className="text-xs text-slate-500">
                Attendance
              </label>

              <input
                type="text"
                defaultValue="78 villagers"
                className={`w-full mt-1 p-2 rounded-lg border text-sm ${
                  isDarkMode
                    ? "bg-slate-900 border-slate-700"
                    : "bg-slate-50 border-slate-300"
                }`}
              />
            </div>

            <div>
              <label className="text-xs text-slate-500">
                Minutes of Meeting
              </label>

              <textarea
                rows="4"
                defaultValue="Discussed land acquisition proposal and addressed villagers' concerns."
                className={`w-full mt-1 p-2 rounded-lg border text-sm ${
                  isDarkMode
                    ? "bg-slate-900 border-slate-700"
                    : "bg-slate-50 border-slate-300"
                }`}
              />
            </div>

            <button className="w-full py-2 rounded-lg bg-blue-600 text-white text-sm font-bold">
              Save & Update Status
            </button>

          </div>

        </div>

      </div>

    </div>
  );
}

export default Notifications;