function LandScrutiny({ isDarkMode }) {
  const card = `rounded-xl border p-5 ${
    isDarkMode
      ? "bg-slate-800 border-slate-700"
      : "bg-white border-slate-200 shadow-sm"
  }`;

  return (
    <div className="space-y-5">

      {/* PAGE HEADER */}
      <div>
        <h1
          className={`text-2xl font-bold ${
            isDarkMode ? "text-white" : "text-slate-900"
          }`}
        >
          Land Scrutiny — Parcel Details
        </h1>

        <p className="text-sm text-slate-500 mt-1">
          Verify land records, review documents and capture field evidence
        </p>
      </div>

      {/* MAIN GRID */}
      <div className="grid grid-cols-2 gap-5">

        {/* BASIC INFORMATION */}
        <div className={card}>

          <div className="flex justify-between items-center mb-5">
            <h2 className="text-lg font-bold">
              Basic Information
            </h2>

            <span className="px-3 py-1 rounded-lg bg-amber-500/20 text-amber-500 text-xs font-bold">
              Pending Review
            </span>
          </div>

          <div className="space-y-4 text-sm">

            <div className="flex justify-between">
              <span className="text-slate-500">Survey No.</span>
              <strong>113</strong>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Landowner Name</span>
              <strong>Sushila Devi</strong>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Official Area</span>
              <strong>0.410 Ha</strong>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Land Classification</span>
              <strong>Residential</strong>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Record Status</span>

              <span className="px-2 py-1 rounded bg-red-500/20 text-red-500 text-xs font-bold">
                Missing RoR
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Remarks</span>
              <strong>RoR not found in records</strong>
            </div>

          </div>
        </div>

        {/* FIELD EVIDENCE */}
        <div className={card}>

          <h2 className="text-lg font-bold mb-4">
            📄 Field Evidence & Notes
          </h2>

          <div className="flex gap-1 mb-4">
            <button className="flex-1 py-2 rounded bg-blue-600 text-white text-xs font-bold">
              Inspection Notes
            </button>

            <button className="flex-1 py-2 rounded bg-slate-700 text-xs">
              Upload Photos
            </button>

            <button className="flex-1 py-2 rounded bg-slate-700 text-xs">
              Field Sketch
            </button>
          </div>

          <label className="text-sm font-bold">
            Field Inspection Notes
          </label>

          <textarea
            rows="4"
            defaultValue="Visited site on 12-09-2025. Land is under residential use. Documents not available with landowner. Told to submit RoR copy within 7 days."
            className={`w-full mt-2 p-3 rounded-lg border text-sm outline-none ${
              isDarkMode
                ? "bg-slate-900 border-slate-700"
                : "bg-slate-50 border-slate-300"
            }`}
          />

        </div>

        {/* ADJACENT PARCELS */}
        <div className={card}>

          <h2 className="text-lg font-bold mb-4">
            🗺️ Adjacent Parcels
          </h2>

          <table className="w-full text-sm">

            <thead className="text-xs text-slate-500 border-b border-slate-700">
              <tr>
                <th className="text-left py-3">Survey No.</th>
                <th className="text-left py-3">Landowner</th>
                <th className="text-left py-3">Relation</th>
                <th className="text-left py-3">Status</th>
              </tr>
            </thead>

            <tbody>

              <tr className="border-b border-slate-700/50">
                <td className="py-3">112</td>
                <td>Ram Prakash</td>
                <td>North</td>
                <td className="text-emerald-500">Verified</td>
              </tr>

              <tr className="border-b border-slate-700/50">
                <td className="py-3">114</td>
                <td>Abdul Rahman</td>
                <td>South</td>
                <td className="text-emerald-500">Verified</td>
              </tr>

              <tr className="border-b border-slate-700/50">
                <td className="py-3">109</td>
                <td>Mohd. Arif</td>
                <td>East</td>
                <td className="text-amber-500">Pending</td>
              </tr>

              <tr>
                <td className="py-3">116</td>
                <td>Ramesh Yadav</td>
                <td>West</td>
                <td className="text-emerald-500">Verified</td>
              </tr>

            </tbody>

          </table>

          <div className="mt-5 p-4 rounded-lg border border-red-500/40 bg-red-500/10">
            <p className="font-bold text-red-500">
              ⚠ Record of Rights (RoR) missing
            </p>

            <p className="text-xs text-slate-500 mt-1">
              Please verify with revenue records and upload the document.
            </p>
          </div>

        </div>

        {/* UPLOADED DOCUMENTS */}
        <div className={card}>

          <h2 className="text-lg font-bold mb-4">
            📁 Uploaded Documents
          </h2>

          <div className="space-y-2">

            {[
              ["📄", "Khasra Copy.pdf", "1.2 MB"],
              ["🖼️", "Field Photo 1.jpg", "3.4 MB"],
              ["🖼️", "Field Photo 2.jpg", "2.1 MB"],
              ["📄", "Aadhaar_Sushila.pdf", "0.8 MB"],
            ].map(([icon, name, size]) => (
              <div
                key={name}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  isDarkMode
                    ? "border-slate-700 bg-slate-900"
                    : "border-slate-200 bg-slate-50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <span>{icon}</span>
                  <span className="text-sm">{name}</span>
                </div>

                <div className="flex gap-4 text-xs">
                  <span className="text-slate-500">{size}</span>
                  <button className="text-blue-500 font-bold">
                    View
                  </button>
                </div>
              </div>
            ))}

          </div>

          {/* UPLOAD */}
          <div className="mt-4 border-2 border-dashed border-blue-500/40 rounded-xl p-8 text-center">

            <p className="text-3xl">☁️</p>

            <p className="font-bold mt-2">
              Upload Documents
            </p>

            <p className="text-xs text-slate-500 mt-1">
              Drag & drop files or choose from your device
            </p>

            <button className="mt-3 px-5 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold">
              Choose Files
            </button>

          </div>

        </div>

      </div>

      {/* ACTION BAR */}
      <div className="flex justify-end gap-3">

        <button className="px-6 py-3 rounded-lg border border-blue-500 text-blue-500 font-bold text-sm">
          Save Draft
        </button>

        <button className="px-6 py-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm">
          ✓ Mark as Verified
        </button>

      </div>

    </div>
  );
}

export default LandScrutiny;