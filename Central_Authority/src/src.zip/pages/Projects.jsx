import { useMemo, useState } from "react";
import { projects } from "../data/projects";
import { stateDistricts } from "../data/stateDistricts";
import { Link } from "react-router-dom";

function Projects() {

  const [search, setSearch] = useState("");

  const [stateFilter, setStateFilter] = useState("All States");
  const [districtFilter, setDistrictFilter] = useState("All Districts");
  const [typeFilter, setTypeFilter] = useState("All Types");
  const [statusFilter, setStatusFilter] = useState("All Status");
  const [sourceFilter, setSourceFilter] = useState("All Sources");

  const [sortBy, setSortBy] = useState("Last Updated (Newest)");
  const [currentPage, setCurrentPage] = useState(1);

  const projectsPerPage = 10;


  /* ----------------------------------
     FILTER OPTIONS
  ---------------------------------- */

  const states = useMemo(
    () => [
      "All States",
      ...new Set(projects.map((project) => project.state)),
    ],
    []
  );


  /*
     DISTRICTS ARE NOW DEPENDENT ON STATE

     If no state is selected:
     District dropdown is disabled.

     If a state is selected:
     Only districts belonging to that state
     are shown.
  */

  const districts = useMemo(() => {

    if (stateFilter === "All States") {
      return ["All Districts"];
    }

    return [
      "All Districts",
      ...(stateDistricts[stateFilter] || []),
    ];

  }, [stateFilter]);


  /*
     WHEN STATE CHANGES:
     Reset district back to All Districts.
  */

  const handleStateChange = (event) => {

    const newState = event.target.value;

    setStateFilter(newState);

    setDistrictFilter("All Districts");

    setCurrentPage(1);
  };


  const projectTypes = useMemo(
    () => [
      "All Types",
      ...new Set(projects.map((project) => project.projectType)),
    ],
    []
  );


  const statuses = useMemo(
    () => [
      "All Status",
      ...new Set(projects.map((project) => project.status)),
    ],
    []
  );


  const sources = useMemo(
    () => [
      "All Sources",
      ...new Set(projects.map((project) => project.source)),
    ],
    []
  );


  /* ----------------------------------
     FILTERING
  ---------------------------------- */

  const filteredProjects = useMemo(() => {

    let result = [...projects];

    const query = search.toLowerCase().trim();


    /* SEARCH */

    if (query) {

      result = result.filter((project) => {

        return (
          project.id.toLowerCase().includes(query) ||
          project.name.toLowerCase().includes(query) ||
          project.state.toLowerCase().includes(query) ||
          project.districts
            .join(" ")
            .toLowerCase()
            .includes(query)
        );

      });

    }


    /* STATE */

    if (stateFilter !== "All States") {

      result = result.filter(
        (project) =>
          project.state === stateFilter
      );

    }


    /* DISTRICT */

    if (districtFilter !== "All Districts") {

      result = result.filter((project) =>
        project.districts.includes(
          districtFilter
        )
      );

    }


    /* PROJECT TYPE */

    if (typeFilter !== "All Types") {

      result = result.filter(
        (project) =>
          project.projectType === typeFilter
      );

    }


    /* STATUS */

    if (statusFilter !== "All Status") {

      result = result.filter(
        (project) =>
          project.status === statusFilter
      );

    }


    /* SOURCE */

    if (sourceFilter !== "All Sources") {

      result = result.filter(
        (project) =>
          project.source === sourceFilter
      );

    }


    /* ----------------------------------
       SORTING
    ---------------------------------- */

    if (sortBy === "Project Name (A-Z)") {

      result.sort((a, b) =>
        a.name.localeCompare(b.name)
      );

    }


    if (sortBy === "Project Name (Z-A)") {

      result.sort((a, b) =>
        b.name.localeCompare(a.name)
      );

    }


    if (sortBy === "Progress (High-Low)") {

      result.sort((a, b) =>
        b.progress - a.progress
      );

    }


    if (sortBy === "Progress (Low-High)") {

      result.sort((a, b) =>
        a.progress - b.progress
      );

    }


    if (sortBy === "Risk (High-Low)") {

      const risk = {
        High: 3,
        Medium: 2,
        Low: 1,
      };

      result.sort(
        (a, b) =>
          risk[b.risk] - risk[a.risk]
      );

    }


    return result;

  }, [
    search,
    stateFilter,
    districtFilter,
    typeFilter,
    statusFilter,
    sourceFilter,
    sortBy,
  ]);


  /* =====================================================
     STATE-WISE PROJECT COUNT
  ===================================================== */

  const stateProjectCounts = useMemo(() => {

    const stateMap = {};


    filteredProjects.forEach((project) => {

      if (!stateMap[project.state]) {
        stateMap[project.state] = 0;
      }

      stateMap[project.state]++;

    });


    const total = filteredProjects.length;


    return Object.entries(stateMap)
      .map(([state, count]) => ({

        state,

        count,

        percentage:
          total > 0
            ? (count / total) * 100
            : 0,

      }))
      .sort(
        (a, b) =>
          b.count - a.count
      );

  }, [filteredProjects]);


  /* ----------------------------------
     PAGINATION
  ---------------------------------- */

  const totalPages = Math.max(
    1,
    Math.ceil(
      filteredProjects.length /
        projectsPerPage
    )
  );


  const startIndex =
    (currentPage - 1) *
    projectsPerPage;


  const displayedProjects =
    filteredProjects.slice(
      startIndex,
      startIndex + projectsPerPage
    );


  /* ----------------------------------
     CLEAR FILTERS
  ---------------------------------- */

  const clearFilters = () => {

    setSearch("");

    setStateFilter(
      "All States"
    );

    setDistrictFilter(
      "All Districts"
    );

    setTypeFilter(
      "All Types"
    );

    setStatusFilter(
      "All Status"
    );

    setSourceFilter(
      "All Sources"
    );

    setCurrentPage(1);

  };


  return (

    <div className="projects-page">


      {/* =========================================
          BREADCRUMB
      ========================================= */}

      <div className="projects-breadcrumb">

        <span>
          Projects
        </span>

        <span className="breadcrumb-arrow">
          ›
        </span>

        <span className="breadcrumb-current">
          All Projects
        </span>

      </div>


      {/* =========================================
          PAGE HEADER
      ========================================= */}

      <div className="projects-heading">

        <div>

          <h1>
            All Projects
          </h1>

          <p>
            View and manage all land acquisition
            projects across India. Use different
            views to explore projects by state,
            district, alphabetical or risk level.
          </p>

        </div>


       <Link
  to="/proposals/new"
  className="propose-project-btn"
>
  <span>＋</span>
  Propose New Project
</Link>

      </div>


      {/* =========================================
          PROJECT ANALYTICS
      ========================================= */}

      <div className="project-analytics">

        <div className="analytics-header">

          <div>

            <h3>
              Project Distribution
            </h3>

            <p>
              Overview of ongoing land acquisition
              projects across states.
            </p>

          </div>


          <span className="analytics-total">

            {stateProjectCounts.reduce(
              (total, item) =>
                total + item.count,
              0
            )}

            {" "}Ongoing Projects

          </span>

        </div>


        <div className="state-chart">

          {stateProjectCounts.map((item) => (

            <div
              className="state-chart-row"
              key={item.state}
            >

              <div className="state-name">
                {item.state}
              </div>


              <div className="state-bar-container">

                <div
                  className="state-bar"
                  style={{
                    width:
                      `${item.percentage}%`,
                  }}
                />

              </div>


              <div className="state-count">
                {item.count}
              </div>

            </div>

          ))}

        </div>

      </div>


      {/* =========================================
          FILTER BAR
      ========================================= */}

      <div className="projects-filter-bar">


        {/* SEARCH */}

        <div className="projects-search">

          <span className="search-icon">
            ⌕
          </span>

          <input
            type="text"
            placeholder="Search projects by name, ID or keywords..."
            value={search}
            onChange={(event) => {

              setSearch(
                event.target.value
              );

              setCurrentPage(1);

            }}
          />

          <span className="search-icon-right">
            ⌕
          </span>

        </div>


        {/* STATE */}

        <select
          value={stateFilter}
          onChange={handleStateChange}
        >

          {states.map((state) => (

            <option key={state}>
              {state}
            </option>

          ))}

        </select>


        {/* DISTRICT */}

        <select
          value={districtFilter}
          onChange={(event) => {

            setDistrictFilter(
              event.target.value
            );

            setCurrentPage(1);

          }}
          disabled={
            stateFilter === "All States"
          }
        >

          {districts.map((district) => (

            <option key={district}>
              {district}
            </option>

          ))}

        </select>


        {/* PROJECT TYPE */}

        <select
          value={typeFilter}
          onChange={(event) => {

            setTypeFilter(
              event.target.value
            );

            setCurrentPage(1);

          }}
        >

          {projectTypes.map((type) => (

            <option key={type}>
              {type}
            </option>

          ))}

        </select>


        {/* STATUS */}

        <select
          value={statusFilter}
          onChange={(event) => {

            setStatusFilter(
              event.target.value
            );

            setCurrentPage(1);

          }}
        >

          {statuses.map((status) => (

            <option key={status}>
              {status}
            </option>

          ))}

        </select>


        {/* SOURCE */}

        <select
          value={sourceFilter}
          onChange={(event) => {

            setSourceFilter(
              event.target.value
            );

            setCurrentPage(1);

          }}
        >

          {sources.map((source) => (

            <option key={source}>
              {source}
            </option>

          ))}

        </select>


        {/* CLEAR */}

        <button
          className="clear-filters"
          onClick={clearFilters}
        >
          Clear Filters
        </button>

      </div>


      {/* =========================================
          PROJECT TABLE CARD
      ========================================= */}

      <section className="projects-table-card">


        {/* TABLE TOP */}

        <div className="projects-table-top">

          <h2>
            {filteredProjects.length} Projects
          </h2>


          <div className="table-controls">

            <span>
              Sort by:
            </span>


            <select
              value={sortBy}
              onChange={(event) =>
                setSortBy(
                  event.target.value
                )
              }
            >

              <option>
                Last Updated (Newest)
              </option>

              <option>
                Project Name (A-Z)
              </option>

              <option>
                Project Name (Z-A)
              </option>

              <option>
                Progress (High-Low)
              </option>

              <option>
                Progress (Low-High)
              </option>

              <option>
                Risk (High-Low)
              </option>

            </select>


            <button className="table-icon active">
              ▤
            </button>

            <button className="table-icon">
              ☷
            </button>

          </div>

        </div>


        {/* =========================================
            TABLE
        ========================================= */}

        <div className="projects-table-container">

          <table>

            <thead>

              <tr>

                <th className="check-column">
                  <input type="checkbox" />
                </th>

                <th>
                  Project ID
                </th>

                <th>
                  Project Name ↕
                </th>

                <th>
                  State ↕
                </th>

                <th>
                  District(s) ↕
                </th>

                <th>
                  Land Required
                  <small>(ha) ↕</small>
                </th>

                <th>
                  Estimated Cost
                  <small>(₹ Cr) ↕</small>
                </th>

                <th>
                  Risk Level ↕
                </th>

                <th>
                  Status ↕
                </th>

                <th>
                  Progress ↕
                </th>

                <th>
                  Last Updated ↕
                </th>

                <th className="actions-column">
                  Actions
                </th>

              </tr>

            </thead>


            <tbody>

              {displayedProjects.map((project) => (

                <tr key={project.id}>


                  {/* CHECKBOX */}

                  <td>
                    <input type="checkbox" />
                  </td>


                  {/* PROJECT ID */}

                  <td>

                    <span className="project-id">
                      {project.id}
                    </span>

                  </td>


                  {/* PROJECT NAME */}

                  <td>

                    <span className="project-name">
                      {project.name}
                    </span>

                  </td>


                  {/* STATE */}

                  <td>
                    {project.state}
                  </td>


                  {/* DISTRICTS */}

                  <td>
                    {project.districts.join(", ")}
                  </td>


                  {/* LAND */}

                  <td>
                    {project.landRequired.toLocaleString()}
                  </td>


                  {/* COST */}

                  <td>
                    {project.estimatedCost}
                  </td>


                  {/* RISK */}

                  <td>

                    <span
                      className={`risk-badge ${
                        project.risk.toLowerCase()
                      }`}
                    >

                      <span />

                      {project.risk}

                    </span>

                  </td>


                  {/* STATUS */}

                  <td>

                    <span
                      className={`status-badge ${
                        getStatusClass(
                          project.status
                        )
                      }`}
                    >

                      {project.status}

                    </span>

                  </td>


                  {/* PROGRESS */}

                  <td>

                    <div className="progress-cell">

                      <span>
                        {project.progress}%
                      </span>


                      <div className="progress-track">

                        <div
                          className={`progress-value ${
                            project.progress === 100
                              ? "complete"
                              : ""
                          }`}
                          style={{
                            width:
                              `${project.progress}%`,
                          }}
                        />

                      </div>

                    </div>

                  </td>


                  {/* LAST UPDATED */}

                  <td>
                    {project.lastUpdated}
                  </td>


                  {/* =================================
                      ACTIONS
                  ================================= */}

                  <td className="actions-column">

                    <div className="action-cell">

                      <Link
                        to={`/projects/${project.id}`}
                        className="details-btn"
                      >
                        View Details
                      </Link>


                      <button
                        className="more-btn"
                        onClick={() =>
                          console.log(
                            "More actions:",
                            project.id
                          )
                        }
                        aria-label={`More actions for ${project.name}`}
                      >
                        •••
                      </button>

                    </div>

                  </td>

                </tr>

              ))}

            </tbody>

          </table>

        </div>


        {/* =========================================
            FOOTER
        ========================================= */}

        <div className="projects-table-footer">


          <span>

            Showing{" "}

            {filteredProjects.length === 0
              ? 0
              : startIndex + 1}

            {" – "}

            {Math.min(
              startIndex + projectsPerPage,
              filteredProjects.length
            )}

            {" "}of{" "}

            {filteredProjects.length}

            {" "}projects

          </span>


          <div className="pagination">


            {/* PREVIOUS */}

            <button
              disabled={
                currentPage === 1
              }
              onClick={() =>
                setCurrentPage(
                  Math.max(
                    1,
                    currentPage - 1
                  )
                )
              }
            >
              ‹
            </button>


            {/* PAGE NUMBERS */}

            {Array.from(
              {
                length: totalPages,
              },
              (_, index) =>
                index + 1
            ).map((page) => (

              <button
                key={page}
                className={
                  page === currentPage
                    ? "active"
                    : ""
                }
                onClick={() =>
                  setCurrentPage(page)
                }
              >
                {page}
              </button>

            ))}


            {/* NEXT */}

            <button
              disabled={
                currentPage === totalPages
              }
              onClick={() =>
                setCurrentPage(
                  Math.min(
                    totalPages,
                    currentPage + 1
                  )
                )
              }
            >
              ›
            </button>

          </div>

        </div>

      </section>

    </div>
  );
}


/* ----------------------------------
   STATUS CLASS
---------------------------------- */

function getStatusClass(status) {

  if (status === "Approved") {
    return "approved";
  }

  if (status === "Completed") {
    return "completed";
  }

  if (status === "Under Review") {
    return "review";
  }

  if (status === "Returned for Correction") {
    return "correction";
  }

  if (status === "Under Acquisition") {
    return "acquisition";
  }

  if (status.includes("Landowner")) {
    return "landowner";
  }

  if (status.includes("Survey")) {
    return "survey";
  }

  if (status.includes("Village")) {
    return "village";
  }

  return "pending";
}


export default Projects;