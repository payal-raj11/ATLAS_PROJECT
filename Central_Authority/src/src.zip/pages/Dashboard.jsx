function Dashboard() {

  return (

    <div className="central-dashboard">

      {/* PAGE HEADER */}

      <div className="page-breadcrumb">

        <span>
          Central Authority
        </span>

        <span>
          ›
        </span>

        <span className="current">
          Dashboard
        </span>

      </div>


      <div className="page-top">

        <div className="page-title">

          <h2>
            Central Authority Dashboard
          </h2>

          <p>
            Centralized overview of land acquisition
            projects and government processes.
          </p>

        </div>

      </div>


      {/* ==========================================
          DASHBOARD SKELETON
          ========================================== */}

      <div className="dashboard-grid">


        <div className="dashboard-card skeleton-card">

          <span className="skeleton-label">
            Total Projects
          </span>

          <span className="skeleton-value">
            —
          </span>

          <span className="skeleton-note">
            Data will be integrated
          </span>

        </div>


        <div className="dashboard-card skeleton-card">

          <span className="skeleton-label">
            Projects Under Review
          </span>

          <span className="skeleton-value">
            —
          </span>

          <span className="skeleton-note">
            Data will be integrated
          </span>

        </div>


        <div className="dashboard-card skeleton-card">

          <span className="skeleton-label">
            Land Under Acquisition
          </span>

          <span className="skeleton-value">
            —
          </span>

          <span className="skeleton-note">
            Data will be integrated
          </span>

        </div>


        <div className="dashboard-card skeleton-card">

          <span className="skeleton-label">
            Funding Allocated
          </span>

          <span className="skeleton-value">
            —
          </span>

          <span className="skeleton-note">
            Data will be integrated
          </span>

        </div>

      </div>


      {/* LOWER DASHBOARD */}

      <div className="dashboard-lower-grid">


        <div className="dashboard-panel">

          <div className="dashboard-panel-header">

            <h3>
              Project Overview
            </h3>

            <span>
              Awaiting data
            </span>

          </div>


          <div className="dashboard-placeholder">

            <div className="dashboard-placeholder-icon">
              ▤
            </div>

            <h3>
              Project analytics
            </h3>

            <p>
              Charts and project statistics
              will appear here once the backend
              is connected.
            </p>

          </div>

        </div>


        <div className="dashboard-panel">

          <div className="dashboard-panel-header">

            <h3>
              Recent Activity
            </h3>

            <span>
              Awaiting data
            </span>

          </div>


          <div className="dashboard-placeholder">

            <div className="dashboard-placeholder-icon">
              ◷
            </div>

            <h3>
              No activity yet
            </h3>

            <p>
              Government actions and project
              updates will appear here.
            </p>

          </div>

        </div>

      </div>


    </div>

  );

}


export default Dashboard;